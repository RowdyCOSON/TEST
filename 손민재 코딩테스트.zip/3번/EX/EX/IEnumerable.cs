﻿using System.Collections;

namespace EX
{
    public interface IEnumerable
    {
        IEnumerator GetEnumerator();
    }
}