﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CounterCheckManager : MonoBehaviour
{
    private CounterCheck counterCheck;
    void Start()
    {
        counterCheck = new CounterCheck();
    }
}
